Link do Capstone Proposal: https://review.udacity.com/#!/reviews/1218357
-------------------------------------------------------------------------

Bibliotecas utilizadas:
tweepy - para captura dos tweets para analise de sentimentos
#https://apps.twitter.com/app/14711331/keys
#https://ronanlopes.me/coletor-de-tweets-em-python-com-o-tweepy/

Dados utilizados:
-----------------------------------------
Dados de tweets extraidos diariamente em horarios diferentes com a palavra Bitcoin (Tratadas.csv)

Tecnicas utilizadas:
-------------------------------
STOP WORD -- https://pythonspot.com/nltk-stop-words/
Stop Word para excluir as palavras que n�o possuem influencia no resultado

STEMMING -- https://pythonprogramming.net/stemming-nltk-tutorial/
Stemming para reduzir as palavras para seu radical

BAG OF WORDS -- https://pythonprogramminglanguage.com/bag-of-words/
Bag of Words para poder treinar o modelo com as palavras vetorizadas
